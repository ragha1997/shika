DECLARE 
	consumern electricity_consumer.consumerno%TYPE;
  units electricity_consumer.unitsconsumed%TYPE;
  ressum number;
  
  BEGIN
	dbms_output.put_line('Enter consumer number :') ;
  consumern := &consumerno ;
  --getDetails(consumerno,unitsconsumed);
  select unitsconsumed into units from electricity_consumer where consumerno = consumern;
  ressum := 0;
  
  IF units <= 100 then
    ressum := units * 02.96;
  ELSE
    ressum := 100 * 02.96 + (units-100)*05.56;
  END IF;
  dbms_output.put_line('Your total bill is '||ressum);
  insert into electricity_bill values (billid_seq.NEXTVAL,consumern,ressum,to_date(sysdate,'dd-mon-yyyy'));
  
EXCEPTION
  WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE('CONSUMER DOESNOT EXIST');

END;
  
  

