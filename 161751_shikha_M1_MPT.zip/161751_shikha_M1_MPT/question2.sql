drop table electricity_Consumer CASCADE CONSTRAINTS;
DROP TABLE Electricity_bill;
drop sequence billid_seq;

create table electricity_Consumer(consumerNo number(8) not null primary key, ConsumerName varchar2(20) not null, emailid varchar2(35), 
unitsConsumed number );

create table electricity_bill(billno number not null primary key, consumerno number, billamount number, billpaiddate date,
foreign key(consumerNo) references electricity_Consumer(consumerNo));

insert into ELECTRICITY_CONSUMER values(1001, 'Seema Joshi','seema.joshi@gmail.com',250);
insert into ELECTRICITY_CONSUMER values(1002, 'Amey Joshi','amey.j@cg.com',345);
insert into ELECTRICITY_CONSUMER values(1003, 'Pravin','pravin.t@cg.com',457);
insert into ELECTRICITY_CONSUMER values(1004, 'Manoj Kulkarni','manoj@gmail.com',780);
insert into ELECTRICITY_CONSUMER values(1005, 'Shrikant Shinde','shrikant.shinde@gmail.com',90);
insert into ELECTRICITY_CONSUMER values(1006, 'Mahesh B','bmahesh@yahoo.com',720);

insert into ELECTRICITY_BILL values(101,1001,440.45, TO_DATE('25-May-2017','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(102,1002,690, TO_DATE('02-Jun-2018','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(103,1001,675, TO_DATE('05-Aug-2017','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(104,1004,678, TO_DATE('05-Aug-2000','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(105,1005,643, TO_DATE('08-Jan-2001','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(106,1004,900, TO_DATE('08-Feb-2010','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(107,1003,842, TO_DATE('12-May-2001','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(108,1002,421, TO_DATE('18-Sep-2009','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(109,1005,346, TO_DATE('20-Aug-2005','dd-mon-yyyy'));
insert into ELECTRICITY_BILL values(110,1005,342, TO_DATE('26-jul-2001','dd-mon-yyyy'));

select * from ELECTRICITY_CONSUMER;
select * from ELECTRICITY_BILL;

2.1

select e.consumerno, e.consumername from electricity_consumer e 
where e.unitsConsumed = (select max(unitsconsumed) from electricity_consumer); 

2.2

select consumerno from electricity_bill 
group by consumerno having count(consumerno)>1;

2.3

create sequence billid_seq start with 111 increment by 1;

--plsql

DECLARE 
	consumern electricity_consumer.consumerno%TYPE;
  units electricity_consumer.unitsconsumed%TYPE;
  ressum number;
  
  BEGIN
	dbms_output.put_line('Enter consumer number :') ; --takes the input
  consumern := &consumerno ;
  --getDetails(consumerno,unitsconsumed);
  select unitsconsumed into units from electricity_consumer where consumerno = consumern; --transfers unitsconsumed into a variable units
  
  --calculation of billamount
  IF units <= 100 then
    ressum := units * 02.96;
  ELSE
    ressum := 100 * 02.96 + (units-100)*05.56;
  END IF;
  dbms_output.put_line('Your total bill is '||ressum);
  insert into electricity_bill values (billid_seq.NEXTVAL,consumern,ressum,to_date(sysdate,'dd-mon-yyyy'));
  --exception handling
EXCEPTION
  WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE('CONSUMER DOESNOT EXIST');

END;


